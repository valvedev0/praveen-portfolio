import asyncio

from sim_launcher import main_async


asyncio.run(main_async(web=True))
