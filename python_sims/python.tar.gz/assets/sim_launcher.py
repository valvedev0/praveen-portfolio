import asyncio
import json
from pathlib import Path

import pygame

from simulations.registry import get_simulation, get_simulations


WINDOW_SIZE = (1220, 640)
FPS = 60

BG = (18, 22, 30)
PANEL = (30, 36, 48)
PANEL_ACTIVE = (42, 54, 74)
TEXT = (235, 240, 246)
MUTED = (158, 170, 186)
ACCENT = (92, 191, 174)
ACCENT_DARK = (38, 123, 116)
LINE = (72, 86, 108)


def load_launcher_config(base_dir):
    config_path = base_dir / "configs" / "launcher_config.json"
    default_config = {
        "title": "Simulation Launcher",
        "subtitle": "Choose a simulation and run it in the shared Pygame canvas.",
    }
    try:
        with open(config_path, "r", encoding="utf-8") as config_file:
            loaded = json.load(config_file)
            if isinstance(loaded, dict):
                default_config.update(loaded)
    except Exception:
        pass
    return default_config


def draw_text(surface, font, text, color, pos):
    surface.blit(font.render(text, True, color), pos)


def draw_wrapped_text(surface, font, text, color, rect, line_height):
    words = text.split()
    lines = []
    current = ""

    for word in words:
        candidate = word if not current else f"{current} {word}"
        if font.size(candidate)[0] <= rect.width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word

    if current:
        lines.append(current)

    y = rect.y
    for line in lines:
        if y + line_height > rect.bottom:
            break
        surface.blit(font.render(line, True, color), (rect.x, y))
        y += line_height

    return y


class PygameLauncher:
    def __init__(self, config):
        self.config = config
        self.entries = list(get_simulations())
        self.selected_index = 0
        self.card_rects = []
        self.start_rect = pygame.Rect(0, 0, 0, 0)

        self.title_font = pygame.font.SysFont("Consolas", 30, bold=True)
        self.subtitle_font = pygame.font.SysFont("Consolas", 16)
        self.card_font = pygame.font.SysFont("Consolas", 20, bold=True)
        self.body_font = pygame.font.SysFont("Consolas", 15)
        self.small_font = pygame.font.SysFont("Consolas", 13)
        self.button_font = pygame.font.SysFont("Consolas", 17, bold=True)

    @property
    def selected_entry(self):
        return self.entries[self.selected_index]

    def handle_event(self, event):
        if not self.entries:
            return None

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_DOWN, pygame.K_s):
                self.selected_index = (self.selected_index + 1) % len(self.entries)
            elif event.key in (pygame.K_UP, pygame.K_w):
                self.selected_index = (self.selected_index - 1) % len(self.entries)
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                return self.selected_entry

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for index, rect in enumerate(self.card_rects):
                if rect.collidepoint(event.pos):
                    self.selected_index = index
                    if getattr(event, "clicks", 1) >= 2:
                        return self.selected_entry
                    return None

            if self.start_rect.collidepoint(event.pos):
                return self.selected_entry

        return None

    def draw(self, surface):
        surface.fill(BG)
        pygame.draw.rect(surface, (13, 17, 24), pygame.Rect(0, 0, WINDOW_SIZE[0], 86))
        pygame.draw.line(surface, LINE, (0, 86), (WINDOW_SIZE[0], 86), 1)

        draw_text(surface, self.title_font, self.config["title"], TEXT, (34, 22))
        draw_text(surface, self.subtitle_font, self.config["subtitle"], MUTED, (36, 58))

        self._draw_sim_list(surface)
        self._draw_details(surface)

    def _draw_sim_list(self, surface):
        self.card_rects = []
        x = 34
        y = 118
        width = 430
        height = 116

        draw_text(surface, self.subtitle_font, "Available simulations", TEXT, (x, y - 30))

        for index, entry in enumerate(self.entries):
            rect = pygame.Rect(x, y + index * (height + 14), width, height)
            self.card_rects.append(rect)

            active = index == self.selected_index
            fill = PANEL_ACTIVE if active else PANEL
            border = ACCENT if active else LINE
            pygame.draw.rect(surface, fill, rect, border_radius=8)
            pygame.draw.rect(surface, border, rect, width=2, border_radius=8)

            draw_text(surface, self.card_font, entry.display_name, TEXT, (rect.x + 18, rect.y + 16))
            draw_text(
                surface,
                self.small_font,
                f"simulations/{entry.folder_name}",
                ACCENT if active else MUTED,
                (rect.x + 18, rect.y + 44),
            )
            draw_wrapped_text(
                surface,
                self.small_font,
                entry.description,
                MUTED,
                pygame.Rect(rect.x + 18, rect.y + 70, rect.width - 36, 34),
                16,
            )

    def _draw_details(self, surface):
        entry = self.selected_entry
        panel_rect = pygame.Rect(506, 118, 680, 440)
        pygame.draw.rect(surface, PANEL, panel_rect, border_radius=8)
        pygame.draw.rect(surface, LINE, panel_rect, width=2, border_radius=8)

        draw_text(surface, self.card_font, entry.display_name, TEXT, (panel_rect.x + 26, panel_rect.y + 26))

        y = draw_wrapped_text(
            surface,
            self.body_font,
            entry.description,
            MUTED,
            pygame.Rect(panel_rect.x + 26, panel_rect.y + 62, panel_rect.width - 52, 72),
            20,
        )
        y += 26

        draw_text(surface, self.subtitle_font, "Controls", TEXT, (panel_rect.x + 26, y))
        y += 30

        for control in entry.controls:
            draw_text(surface, self.body_font, control, MUTED, (panel_rect.x + 38, y))
            y += 24

        draw_text(
            surface,
            self.small_font,
            "Launcher: Up/Down selects, Enter starts, double-click a simulation to start.",
            MUTED,
            (panel_rect.x + 26, panel_rect.bottom - 48),
        )

        self.start_rect = pygame.Rect(panel_rect.x + 26, panel_rect.bottom + 22, 190, 46)
        pygame.draw.rect(surface, ACCENT_DARK, self.start_rect, border_radius=8)
        pygame.draw.rect(surface, ACCENT, self.start_rect, width=2, border_radius=8)
        label = self.button_font.render("Run Selected", True, TEXT)
        label_pos = label.get_rect(center=self.start_rect.center)
        surface.blit(label, label_pos)


async def main_async(initial_sim=None, web=False):
    base_dir = Path(__file__).resolve().parent
    config = load_launcher_config(base_dir)

    pygame.init()
    pygame.font.init()
    screen = pygame.display.set_mode(WINDOW_SIZE)
    pygame.display.set_caption(config["title"])
    clock = pygame.time.Clock()

    launcher = PygameLauncher(config)
    active_entry = None
    active_scene = None
    running = True

    def start_simulation(entry):
        nonlocal active_entry, active_scene
        active_entry = entry
        active_scene = entry.scene_factory()
        pygame.display.set_caption(entry.display_name)

    if initial_sim:
        try:
            start_simulation(get_simulation(initial_sim))
        except KeyError:
            active_entry = None
            active_scene = None

    try:
        while running:
            dt = clock.tick(FPS) / 1000.0
            mouse_pos = pygame.mouse.get_pos()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    break

                if active_scene is not None:
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                        active_entry = None
                        active_scene = None
                        pygame.display.set_caption(config["title"])
                    elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                        active_scene.reset()
                    else:
                        active_scene.handle_event(event)
                else:
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                        running = False
                    else:
                        selected = launcher.handle_event(event)
                        if selected is not None:
                            start_simulation(selected)

            if active_scene is not None:
                active_scene.fps = clock.get_fps()
                active_scene.update(dt, pygame.key.get_pressed(), mouse_pos)
                active_scene.draw(screen)
            else:
                launcher.draw(screen)

            pygame.display.flip()
            await asyncio.sleep(0)
    finally:
        if not web:
            pygame.quit()


def run_simulation_direct(sim_key):
    asyncio.run(main_async(initial_sim=sim_key, web=False))


def main():
    asyncio.run(main_async(web=False))


if __name__ == "__main__":
    main()
