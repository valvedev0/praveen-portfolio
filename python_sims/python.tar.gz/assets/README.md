# Python Simulations (Pygame + WebAssembly)

This project contains multiple Pygame simulations and a shared launcher that can run on desktop or be packaged for the browser with Pygbag.

## Project Structure

```text
python/
  main.py                       # Pygbag-required web entry point
  pygbag.ini                    # Pygbag packaging ignore rules
  sim_launcher.py               # Shared desktop/web Pygame launcher
  configs/
    launcher_config.json        # Launcher text config
  simulations/
    registry.py                 # Simulation list used by the launcher
    ant/
      ant_sim.py                # Ant scene
      run.py                    # Direct desktop entry point
    flight/
      flight_sim.py             # Flight scene
      run.py                    # Direct desktop entry point
    laser/
      laser_sim.py              # Laser scene
      run.py                    # Direct desktop entry point
```

## Prerequisites

- Python 3.12+ for local development
- `uv` or `pip`
- `pygame-ce`
- `pygbag` for browser builds

## Setup

From this folder:

```powershell
uv venv --clear --python 3.12 .venv
uv pip install -r requirements.txt
```

For WebAssembly builds:

```powershell
uv pip install -r requirements-web.txt
```

Using plain pip also works:

```powershell
python -m pip install -r requirements.txt
python -m pip install -r requirements-web.txt
```

## Run Locally

Start the shared launcher:

```powershell
python sim_launcher.py
```

Or with Make:

```powershell
make run
```

Run a simulation directly:

```powershell
python simulations\ant\run.py
python simulations\flight\run.py
python simulations\laser\run.py
```

Launcher controls:

- Up/Down or W/S: select simulation
- Enter/Space: run selected simulation
- Double-click: run a simulation
- Escape in launcher: close
- Escape in a simulation: return to launcher
- R in a simulation: reset it

## Build For The Web

Run the Pygbag development server:

```powershell
python -m pygbag .
```

Then open:

```text
http://localhost:8000
```

Create static web files:

```powershell
python -m pygbag --build --app_name "Simulation Launcher" --title "Simulation Launcher" .
```

Or with Make:

```powershell
make web-build
```

The copyable web output is generated here:

```text
build/web/
```

Copy the full contents of `build/web/` into the target folder in your portfolio repo, including `.nojekyll` when it exists, then serve that folder through GitHub Pages.

## Adding New Simulations

- Create a new folder under `simulations/`.
- Implement a scene object with:
  - `reset()`
  - `handle_event(event)`
  - `update(dt, keys, mouse_pos)`
  - `draw(surface)`
  - `size`
  - `title`
- Add the scene to `simulations/registry.py`.
- Add a `run.py` that calls `run_simulation_direct("<key>")`.

Keep browser compatibility in mind: do not create a second Pygame event loop inside a scene, do not call `pygame.display.set_mode()` inside a scene, and do not call `pygame.quit()` from scene modules.
