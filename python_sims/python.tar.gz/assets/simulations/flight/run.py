import sys
from pathlib import Path


def main():
    repo_root = Path(__file__).resolve().parents[2]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

    from sim_launcher import run_simulation_direct

    run_simulation_direct("flight")


if __name__ == "__main__":
    main()
