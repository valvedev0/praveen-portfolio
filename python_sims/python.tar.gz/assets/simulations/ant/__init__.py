"""Ant simulation package."""
