import random
import time
from collections import deque
from pathlib import Path
import sys

import pygame


SIM_WIDTH = 800
UI_WIDTH = 300
HEIGHT = 600
SIZE = (SIM_WIDTH + UI_WIDTH, HEIGHT)


class Target:
    def __init__(self, name, color):
        self.pos = pygame.math.Vector2(
            random.randint(50, SIM_WIDTH - 50), random.randint(50, HEIGHT - 50)
        )
        self.color = color
        self.name = name
        self.ants_arrived = 0


class Obstacle:
    def __init__(self):
        self.pos = pygame.math.Vector2(
            random.randint(100, SIM_WIDTH - 100), random.randint(100, HEIGHT - 100)
        )
        self.radius = random.randint(20, 45)


class Ant:
    def __init__(self, target_obj):
        self.pos = pygame.math.Vector2(
            random.randint(10, 50), random.randint(10, HEIGHT - 10)
        )
        self.velocity = pygame.math.Vector2(0, 0)
        self.speed = random.uniform(0.6, 0.8)
        self.target = target_obj
        self.color = target_obj.color
        self.path = [pygame.math.Vector2(self.pos)]
        self.distance_traveled = 0.0
        self.arrived = False

    def update(self, obstacles):
        diagnostics = {"arrived_now": False, "avoidance_hits": 0}

        if self.arrived:
            return diagnostics

        distance_to_target = self.pos.distance_to(self.target.pos)
        if distance_to_target < 10:
            self.arrived = True
            self.target.ants_arrived += 1
            diagnostics["arrived_now"] = True
            return diagnostics

        direction = self.target.pos - self.pos
        if direction.length() > 0:
            direction = direction.normalize()

        wander = pygame.math.Vector2(
            random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5)
        )
        avoidance = pygame.math.Vector2(0, 0)

        for obs in obstacles:
            dist_to_obs = self.pos.distance_to(obs.pos)
            sight_radius = obs.radius + 30
            if 0 < dist_to_obs < sight_radius:
                diagnostics["avoidance_hits"] += 1
                push_vector = self.pos - obs.pos
                push_vector = push_vector.normalize()
                strength = (sight_radius - dist_to_obs) / sight_radius
                avoidance += push_vector * (strength * 3.0)

        self.velocity = direction + wander + avoidance
        if self.velocity.length() > 0:
            self.velocity = self.velocity.normalize() * self.speed

        old_pos = pygame.math.Vector2(self.pos)
        self.pos += self.velocity
        self.distance_traveled += self.pos.distance_to(old_pos)

        if self.pos.distance_to(self.path[-1]) > 5:
            self.path.append(pygame.math.Vector2(self.pos))

        return diagnostics

    def draw(self, surface):
        if len(self.path) > 1:
            pygame.draw.lines(surface, self.color, False, self.path, 1)
        pygame.draw.circle(surface, self.color, (int(self.pos.x), int(self.pos.y)), 3)


class AntSimulationScene:
    title = "Advanced Ant Simulation"
    size = SIZE

    def __init__(self):
        self.ui_font = pygame.font.SysFont("Consolas", 14)
        self.title_font = pygame.font.SysFont("Consolas", 18, bold=True)
        self.fps = 0.0
        self.reset()

    def reset(self):
        self.targets = [
            Target("Red Base", (255, 50, 50)),
            Target("Blue Base", (50, 150, 255)),
            Target("Green Base", (50, 255, 50)),
        ]
        self.obstacles = [Obstacle() for _ in range(5)]
        self.ants = [Ant(self.targets[i % len(self.targets)]) for i in range(30)]

        self.frame_idx = 0
        self.sim_start = time.perf_counter()
        self.events_total = 0
        self.quit_events = 0
        self.keydown_events = 0
        self.mousebutton_events = 0
        self.avoidance_this_frame = 0

        self.frame_ms_history = deque(maxlen=120)
        self.update_ms_history = deque(maxlen=120)
        self.render_ms_history = deque(maxlen=120)
        self._frame_start = time.perf_counter()

    def handle_event(self, event):
        self.events_total += 1
        if event.type == pygame.QUIT:
            self.quit_events += 1
        elif event.type == pygame.KEYDOWN:
            self.keydown_events += 1
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self.mousebutton_events += 1

    def update(self, _dt, _held_keys, _mouse_pos):
        self._frame_start = time.perf_counter()
        update_start = time.perf_counter()
        self.frame_idx += 1
        self.avoidance_this_frame = 0

        for ant in self.ants:
            ant_diag = ant.update(self.obstacles)
            self.avoidance_this_frame += ant_diag["avoidance_hits"]

        update_ms = (time.perf_counter() - update_start) * 1000.0
        self.update_ms_history.append(update_ms)

    def draw(self, surface):
        render_start = time.perf_counter()
        surface.fill((30, 30, 30))

        ui_rect = pygame.Rect(SIM_WIDTH, 0, UI_WIDTH, HEIGHT)
        pygame.draw.rect(surface, (15, 15, 20), ui_rect)
        pygame.draw.line(surface, (100, 100, 100), (SIM_WIDTH, 0), (SIM_WIDTH, HEIGHT), 2)

        for obs in self.obstacles:
            pygame.draw.circle(
                surface,
                (100, 100, 100),
                (int(obs.pos.x), int(obs.pos.y)),
                obs.radius,
            )
            pygame.draw.circle(
                surface,
                (70, 70, 70),
                (int(obs.pos.x), int(obs.pos.y)),
                obs.radius + 30,
                1,
            )

        for target in self.targets:
            pygame.draw.circle(
                surface,
                target.color,
                (int(target.pos.x), int(target.pos.y)),
                12,
            )
            pygame.draw.circle(
                surface,
                (255, 255, 255),
                (int(target.pos.x), int(target.pos.y)),
                12,
                2,
            )

        for ant in self.ants:
            ant.draw(surface)

        self._draw_diagnostics(surface)

        render_ms = (time.perf_counter() - render_start) * 1000.0
        frame_ms = (time.perf_counter() - self._frame_start) * 1000.0
        self.render_ms_history.append(render_ms)
        self.frame_ms_history.append(frame_ms)

    def _draw_diagnostics(self, surface):
        y_offset = 16
        title_surface = self.title_font.render("SIM DIAGNOSTICS", True, (255, 255, 255))
        surface.blit(title_surface, (SIM_WIDTH + 20, y_offset))
        y_offset += 32

        elapsed = time.perf_counter() - self.sim_start
        arrived_total = sum(1 for ant in self.ants if ant.arrived)
        avg_path_all = (
            sum(ant.distance_traveled for ant in self.ants) / len(self.ants)
            if self.ants
            else 0
        )

        avg_frame_ms = (
            sum(self.frame_ms_history) / len(self.frame_ms_history)
            if self.frame_ms_history
            else 0
        )
        avg_update_ms = (
            sum(self.update_ms_history) / len(self.update_ms_history)
            if self.update_ms_history
            else 0
        )
        avg_render_ms = (
            sum(self.render_ms_history) / len(self.render_ms_history)
            if self.render_ms_history
            else 0
        )

        diagnostics_lines = [
            f"Elapsed: {elapsed:7.2f} s",
            f"Frame: {self.frame_idx}",
            f"FPS: {self.fps:6.2f}",
            f"Frame ms(avg): {avg_frame_ms:6.3f}",
            f"Update ms(avg): {avg_update_ms:6.3f}",
            f"Render ms(avg): {avg_render_ms:6.3f}",
            f"Arrived: {arrived_total} / {len(self.ants)}",
            f"Avg Path(all): {avg_path_all:7.2f} px",
            f"Avoidance hits(f): {self.avoidance_this_frame}",
            f"Events total: {self.events_total}",
            f"  quit/key/mouse: {self.quit_events}/{self.keydown_events}/{self.mousebutton_events}",
        ]

        for line in diagnostics_lines:
            text_surface = self.ui_font.render(line, True, (210, 210, 210))
            surface.blit(text_surface, (SIM_WIDTH + 20, y_offset))
            y_offset += 18

        y_offset += 6
        for target in self.targets:
            target_ants = [ant for ant in self.ants if ant.target == target]
            avg_dist = (
                sum(ant.distance_traveled for ant in target_ants) / len(target_ants)
                if target_ants
                else 0
            )

            text_name = self.ui_font.render(f"Target: {target.name}", True, target.color)
            text_arrived = self.ui_font.render(
                f"Arrived: {target.ants_arrived} / {len(target_ants)}",
                True,
                (200, 200, 200),
            )
            text_dist = self.ui_font.render(
                f"Avg Path Length: {avg_dist:.0f} px", True, (200, 200, 200)
            )

            surface.blit(text_name, (SIM_WIDTH + 20, y_offset))
            surface.blit(text_arrived, (SIM_WIDTH + 20, y_offset + 18))
            surface.blit(text_dist, (SIM_WIDTH + 20, y_offset + 36))
            y_offset += 68


def main():
    repo_root = Path(__file__).resolve().parents[2]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

    from sim_launcher import run_simulation_direct

    run_simulation_direct("ant")


if __name__ == "__main__":
    main()
