"""Laser simulation package."""
