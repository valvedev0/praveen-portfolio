import math
import random
from pathlib import Path
import sys

import pygame


SIM_WIDTH = 800
UI_WIDTH = 300
HEIGHT = 600
SIZE = (SIM_WIDTH + UI_WIDTH, HEIGHT)
MAX_BOUNCES = 50


class Mirror:
    def __init__(self, p1, p2):
        self.p1 = pygame.math.Vector2(p1)
        self.p2 = pygame.math.Vector2(p2)
        self.line_vec = self.p2 - self.p1
        self.normal = pygame.math.Vector2(-self.line_vec.y, self.line_vec.x)
        if self.normal.length() > 0:
            self.normal = self.normal.normalize()

    def draw(self, surface):
        pygame.draw.line(surface, (200, 255, 255), self.p1, self.p2, 4)


def get_intersection(ray_origin, ray_dir, mirror):
    x1, y1 = ray_origin.x, ray_origin.y
    x2, y2 = ray_origin.x + ray_dir.x, ray_origin.y + ray_dir.y
    x3, y3 = mirror.p1.x, mirror.p1.y
    x4, y4 = mirror.p2.x, mirror.p2.y

    den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if den == 0:
        return None

    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
    u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den

    if t > 0 and 0 <= u <= 1:
        pt_x = x1 + t * (x2 - x1)
        pt_y = y1 + t * (y2 - y1)
        return pygame.math.Vector2(pt_x, pt_y)
    return None


def calculate_reflection(incoming_vec, normal_vec):
    dot_product = incoming_vec.dot(normal_vec)
    reflection = incoming_vec - 2 * dot_product * normal_vec
    return reflection.normalize()


class LaserSimulationScene:
    title = "Advanced Optics: Laser Reflection"
    size = SIZE

    def __init__(self):
        self.ui_font = pygame.font.SysFont("Consolas", 14)
        self.title_font = pygame.font.SysFont("Consolas", 18, bold=True)
        self.fps = 0.0
        self.reset()

    def reset(self):
        self.mirrors = [
            Mirror((10, 10), (SIM_WIDTH - 10, 10)),
            Mirror((SIM_WIDTH - 10, 10), (SIM_WIDTH - 10, HEIGHT - 10)),
            Mirror((SIM_WIDTH - 10, HEIGHT - 10), (10, HEIGHT - 10)),
            Mirror((10, HEIGHT - 10), (10, 10)),
        ]

        for _ in range(6):
            x = random.randint(50, SIM_WIDTH - 150)
            y = random.randint(50, HEIGHT - 150)
            angle = random.uniform(0, math.pi * 2)
            length = random.randint(80, 150)
            p2_x = x + math.cos(angle) * length
            p2_y = y + math.sin(angle) * length
            self.mirrors.append(Mirror((x, y), (p2_x, p2_y)))

        self.laser_origin = pygame.math.Vector2(SIM_WIDTH // 2, HEIGHT // 2)
        self.beam_segments = []
        self.impact_points = []
        self.bounces = 0
        self.total_distance = 0
        self.events_total = 0
        self.mousebutton_events = 0
        self.keydown_events = 0

    def handle_event(self, event):
        self.events_total += 1
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.mousebutton_events += 1
        elif event.type == pygame.KEYDOWN:
            self.keydown_events += 1

    def update(self, _dt, _held_keys, mouse_pos):
        mouse_vec = pygame.math.Vector2(mouse_pos)
        laser_dir = mouse_vec - self.laser_origin
        if laser_dir.length() > 0:
            laser_dir = laser_dir.normalize()
        else:
            laser_dir = pygame.math.Vector2(1, 0)

        current_origin = pygame.math.Vector2(self.laser_origin)
        current_dir = pygame.math.Vector2(laser_dir)
        self.beam_segments = []
        self.impact_points = []
        self.bounces = 0
        self.total_distance = 0

        while self.bounces < MAX_BOUNCES:
            closest_pt = None
            closest_dist = float("inf")
            hit_mirror = None

            for mirror in self.mirrors:
                pt = get_intersection(current_origin, current_dir, mirror)
                if pt:
                    dist = current_origin.distance_to(pt)
                    if 0.1 < dist < closest_dist:
                        closest_dist = dist
                        closest_pt = pt
                        hit_mirror = mirror

            if closest_pt:
                self.beam_segments.append((pygame.math.Vector2(current_origin), closest_pt))
                self.impact_points.append(closest_pt)
                self.total_distance += closest_dist
                current_origin = closest_pt
                current_dir = calculate_reflection(current_dir, hit_mirror.normal)
                self.bounces += 1
            else:
                end_pt = current_origin + (current_dir * 2000)
                self.beam_segments.append((pygame.math.Vector2(current_origin), end_pt))
                break

    def draw(self, surface):
        surface.fill((10, 10, 15))

        for mirror in self.mirrors:
            mirror.draw(surface)

        pygame.draw.circle(
            surface,
            (255, 50, 50),
            (int(self.laser_origin.x), int(self.laser_origin.y)),
            8,
        )

        for start, end in self.beam_segments:
            pygame.draw.line(surface, (255, 50, 50), start, end, 2)

        for point in self.impact_points:
            pygame.draw.circle(surface, (255, 255, 255), (int(point.x), int(point.y)), 3)

        ui_rect = pygame.Rect(SIM_WIDTH, 0, UI_WIDTH, HEIGHT)
        pygame.draw.rect(surface, (20, 20, 25), ui_rect)
        pygame.draw.line(surface, (100, 100, 100), (SIM_WIDTH, 0), (SIM_WIDTH, HEIGHT), 2)

        y_offset = 20
        title_surface = self.title_font.render("OPTICS ANALYTICS", True, (255, 255, 255))
        surface.blit(title_surface, (SIM_WIDTH + 20, y_offset))
        y_offset += 40

        stats = [
            f"Active Mirrors: {len(self.mirrors)}",
            f"Laser Bounces:  {self.bounces} / {MAX_BOUNCES}",
            f"Total Distance: {self.total_distance:.0f} px",
            f"FPS:             {self.fps:6.2f}",
            "",
            "Controls:",
            "Move mouse: steer beam",
            "R: reset mirrors",
            "ESC: launcher",
        ]

        for stat in stats:
            color = (200, 200, 200) if stat else (120, 120, 120)
            text_surface = self.ui_font.render(stat, True, color)
            surface.blit(text_surface, (SIM_WIDTH + 20, y_offset))
            y_offset += 30 if stat else 12


def main():
    repo_root = Path(__file__).resolve().parents[2]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))

    from sim_launcher import run_simulation_direct

    run_simulation_direct("laser")


if __name__ == "__main__":
    main()
