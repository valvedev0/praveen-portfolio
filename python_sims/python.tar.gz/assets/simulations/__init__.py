"""Simulation scenes used by the shared launcher."""
