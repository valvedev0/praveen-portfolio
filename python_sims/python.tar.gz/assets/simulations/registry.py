from dataclasses import dataclass

from simulations.ant.ant_sim import AntSimulationScene
from simulations.flight.flight_sim import FlightSimulationScene
from simulations.laser.laser_sim import LaserSimulationScene


@dataclass(frozen=True)
class SimulationEntry:
    key: str
    display_name: str
    folder_name: str
    description: str
    controls: tuple[str, ...]
    scene_factory: type


SIMULATIONS = (
    SimulationEntry(
        key="ant",
        display_name="Ant Simulation",
        folder_name="ant",
        description="Swarming ants seek colored bases while avoiding obstacles.",
        controls=("R: reset", "ESC: back to launcher"),
        scene_factory=AntSimulationScene,
    ),
    SimulationEntry(
        key="flight",
        display_name="Flight Simulation",
        folder_name="flight",
        description="Pilot a small aircraft, set waypoints, and inspect live diagnostics.",
        controls=(
            "W/S or Up/Down: throttle",
            "A/D or Left/Right: turn",
            "LMB: set waypoint",
            "RMB or P: toggle autopilot",
            "SPACE: zero velocity",
            "R: reset",
            "ESC: back to launcher",
        ),
        scene_factory=FlightSimulationScene,
    ),
    SimulationEntry(
        key="laser",
        display_name="Laser Reflection",
        folder_name="laser",
        description="Steer a laser through mirror reflections with the mouse.",
        controls=("Mouse: aim laser", "R: reset mirrors", "ESC: back to launcher"),
        scene_factory=LaserSimulationScene,
    ),
)


def get_simulations():
    return SIMULATIONS


def get_simulation(key):
    for entry in SIMULATIONS:
        if entry.key == key or entry.folder_name == key:
            return entry
    raise KeyError(f"Unknown simulation: {key}")
